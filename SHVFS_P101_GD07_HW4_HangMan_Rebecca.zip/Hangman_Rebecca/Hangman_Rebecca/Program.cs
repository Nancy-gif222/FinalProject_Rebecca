﻿using System;
using System.Collections.Generic;

namespace Hangman_Rebecca
{
    class Program
    {
        public static string correctWord;
        public static char[] guessWord;
        public static char[,] hangman=new char[9,7];
        public static int wrongTimes = 0;
        public static int countNum = 0;
        public static bool isCorrect;
        public static string[] myDictionary =
        {
            "tiger","giraffe","lion","deer","leopard","monkey","horse","elephant",
            "bear","donkey","sheep","camel","zebra","octopus","mouse","rabbit",
            "chicken","panda","penguin","beaver","parrot","cricket","crane"
        };
        static void Main(string[] args)
        {
            #region Draw the start screen
            var title = "HANGMAN";
            Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Title = "Hangman";
            Console.WriteLine(title);
            title = "Press any key to start...";
            Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(title);
            Console.ReadKey();
            #endregion

            #region Variable
            string guessLetter;
            #endregion

            //随机生成单词
            Random ram = new Random();
            int ranNum = ram.Next(0, myDictionary.Length);
            correctWord = myDictionary[ranNum];

            //random a word
            guessWord = new char[correctWord.Length];
            //初始化hangman
            InitiateHangman();
            //initiate the guessWord
            for (int i=0;i<guessWord.Length;i++)
            {
                guessWord[i] = '_';
            }

            while (true)
            {
                Console.Clear();
                for (int i = 0; i < guessWord.Length; i++)
                {
                    Console.Write(guessWord[i]);
                }
                Console.WriteLine();
                DrawHangman(wrongTimes);
                Console.WriteLine("\nEnter a letter");
                while (true)
                {
                    guessLetter = Console.ReadLine();
                    if (guessLetter.Length > 1||guessLetter=="")
                    {
                        Console.WriteLine("Please enter ONLY ONE letter!");
                        continue;
                    }

                    else
                    {
                        IsCorrect(guessLetter);
                        break;
                    }
                }
                if (isCorrect ==false)
                {
                                    
                    //判断是否是最后一笔，游戏结束
                    wrongTimes++;
                    //画一笔
                   // Console.WriteLine($"Wrong: {wrongTimes}");
                    if(wrongTimes==6)
                    {
                        Console.Clear();
                        DrawHangman(wrongTimes);
                        Console.WriteLine("You lose!");
                        Console.WriteLine($"The correct word is {correctWord}");
                        Console.WriteLine("Press enter to restart or press Q to exit");
                        var key = Console.ReadKey(true);
                        if(key.Key==ConsoleKey.Q)
                        {
                            break;
                        }
                        RestartFunc();
                    }
                    
                }
                //判断游戏是否胜利，游戏结束
                for (int i = 0; i < guessWord.Length; i++)
                {
                    if (guessWord[i] == '_')
                    {
                        countNum = 0;
                        break;
                    }
                    else
                        countNum++;
                }
                if(countNum==guessWord.Length)
                {
                    Console.WriteLine("You win!");
                    Console.WriteLine("Press enter to restart or press Q to exit");
                    var key = Console.ReadKey(true);
                    if (key.Key == ConsoleKey.Q)
                    {
                        break;
                    }
                    RestartFunc();
                }
            }
            //
        }
        public static void InitiateHangman()
        {
            for (int i = 0; i < hangman.GetLength(0); i++)
            {
                for (int j = 0; j < hangman.GetLength(1); j++)
                {
                    hangman[i, j] = ' ';
                }
            }
            hangman[8, 0] = '_';
            hangman[8, 1] = '_';
            hangman[8, 2] = '_';
            hangman[8, 3] = '_';
            hangman[7, 2] = '|';
            hangman[6, 2] = '|';
            hangman[5, 2] = '|';
            hangman[4, 2] = '|';
            hangman[3, 2] = '|';
            hangman[2, 2] = '|';
            hangman[1, 2] = '|';
            hangman[0, 2] = '|';
            hangman[0, 3] = '_';
            hangman[0, 4] = '_';
            hangman[0, 5] = '_';
            hangman[1, 5] = '|';
         
        }
        public static void DrawHangman(int num)
        {
            switch(num)
            {
                case 1:
                    hangman[2, 5] = 'o';
                    break;
                case 2:
                    hangman[3, 5] = '|';
                    hangman[4, 5] = '|';
                    break;
                case 3:
                    hangman[3,4]='\\';
                    break;
                case 4:
                    hangman[3, 6] = '/';
                    break;
                case 5:
                    hangman[5, 4] = '/';
                    break;
                case 6:
                    hangman[5, 6] = '\\';
                    break;
            }
            for(int i=0;i<hangman.GetLength(0);i++)
            {
                for (int j = 0; j < hangman.GetLength(1); j++)
                {
                    Console.Write(hangman[i, j]);
                }
                Console.WriteLine();
            }

        }
        public static  void IsCorrect(string guessLetter)
        {
            char[] letter = guessLetter.ToCharArray();
            isCorrect = false;
            for (int i=0;i<correctWord.Length;i++)
            {
                if(correctWord[i]==letter[0]&&guessWord[i]=='_')
                {
                    guessWord[i] = letter[0];
                    isCorrect = true;
                }
            }
        }
        public static void RestartFunc()
        {
            Console.Clear();
            //随机生成单词
            Random ram = new Random();
            int ranNum = ram.Next(0, myDictionary.Length);
            correctWord = myDictionary[ranNum];
            //random a word
            guessWord = new char[correctWord.Length];
            //随机一个字母赋给correctWord
            guessWord = new char[correctWord.Length];
            wrongTimes = 0;
            countNum = 0;
            InitiateHangman();
            for (int i = 0; i < guessWord.Length; i++)
            {
                guessWord[i] = '_';
            }
        }
    }
}
